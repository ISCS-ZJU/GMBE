#include "Utility.h"
#include <string.h>
#ifdef _MSC_VER
#include <windows.h>
#include <psapi.h>
#define fopen64 fopen
double get_cur_time() {
  LARGE_INTEGER nFreq;
  LARGE_INTEGER nTime;
  QueryPerformanceFrequency(&nFreq);
  QueryPerformanceCounter(&nTime);
  double time = (double)nTime.QuadPart / (double)nFreq.QuadPart;
  return time;
}

#else
#include <sys/time.h> /* gettimeofday */
#include <stdio.h>
double get_cur_time() {
  struct timeval tv;
  struct timezone tz;
  double cur_time;
  gettimeofday(&tv, &tz);
  cur_time = tv.tv_sec + tv.tv_usec / 1000000.0;
  return cur_time;
}
#define VMHWM_LINE 21
unsigned int get_proc_vmhwm(unsigned int pid){

	char file_name[64]={0};
	FILE *fd;
	char line_buff[512]={0};
	sprintf(file_name,"/proc/%d/status",pid);

	fd =fopen(file_name,"r");
	if(nullptr == fd){
		return 0;
	}

	char name[64];
	int vmhwm;
	for (int i=0; i<VMHWM_LINE-1;i++){
		fgets(line_buff,sizeof(line_buff),fd);
	}

    while(true)
    {
	    fgets(line_buff,sizeof(line_buff),fd);
	    sscanf(line_buff,"%s %d",name,&vmhwm);
        if(!strcmp(name, "VmHWM:"))
        {
            break;
        }
    }
    
    fclose(fd);

	return vmhwm;
}
#endif

std::vector<int> seq_intersect(const std::vector<int>& v0,
                               const std::vector<int>& v1) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = v0.begin(), it1 = v1.begin();
       it0 != v0.end() && it1 != v1.end();) {
    if (*it0 == *it1) {
      res.emplace_back(*it0);
      it0++;
      it1++;
    } else if (*it0 > *it1)
      it1++;
    else
      it0++;
  }
  return res;
}

int seq_intersect_cnt(const std::vector<int>& v0, const std::vector<int>& v1) {
  g_set_op_counter++;
  int cnt = 0;
  for (auto it0 = v0.begin(), it1 = v1.begin();
       it0 != v0.end() && it1 != v1.end();) {
    if (*it0 == *it1) {
      cnt++;
      it0++;
      it1++;
    } else if (*it0 > *it1)
      it1++;
    else
      it0++;
  }
  return cnt;
}

std::vector<int> seq_except(const std::vector<int>& v0,
                            const std::vector<int>& v1) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = v0.begin(), it1 = v1.begin(); it0 != v0.end();) {
    if (it1 == v1.end() || *it0 < *it1) {
      res.emplace_back(*it0);
      it0++;
    } else if (*it0 == *it1) {
      it0++;
      it1++;
    } else {
      it1++;
    }
  }
  return res;
}

std::vector<int> seq_union(const std::vector<int>& v0,
                           const std::vector<int>& v1) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = v0.begin(), it1 = v1.begin();
       it0 != v0.end() || it1 != v1.end();) {
    if (it1 == v1.end())
      res.emplace_back(*it0++);
    else if (it0 == v0.end())
      res.emplace_back(*it1++);
    else if (*it0 == *it1) {
      res.emplace_back(*it0);
      it0++;
      it1++;
    } else if (*it0 > *it1) {
      res.emplace_back(*it1);
      it1++;
    } else {
      res.emplace_back(*it0);
      it0++;
    }
  }
  return res;
}

std::vector<int> seq_intersect_upper(const std::vector<int>& v0,
                                     const std::vector<int>& v1, int bound) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = std::upper_bound(v0.begin(), v0.end(), bound),
            it1 = std::upper_bound(v1.begin(), v1.end(), bound);
       it0 != v0.end() && it1 != v1.end();) {
    if (*it0 == *it1) {
      res.emplace_back(*it0);
      it0++;
      it1++;
    } else if (*it0 > *it1)
      it1++;
    else
      it0++;
  }
  return res;
}

int seq_intersect_cnt_upper(const std::vector<int>& v0,
                            const std::vector<int>& v1, int bound) {
  g_set_op_counter++;
  int cnt = 0;
  for (auto it0 = std::upper_bound(v0.begin(), v0.end(), bound),
            it1 = std::upper_bound(v1.begin(), v1.end(), bound);
       it0 != v0.end() && it1 != v1.end();) {
    if (*it0 == *it1) {
      cnt++;
      it0++;
      it1++;
    } else if (*it0 > *it1)
      it1++;
    else
      it0++;
  }
  return cnt;
}

std::vector<int> seq_except_upper(const std::vector<int>& v0,
                                  const std::vector<int>& v1, int bound) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = std::upper_bound(v0.begin(), v0.end(), bound),
            it1 = std::upper_bound(v1.begin(), v1.end(), bound);
       it0 != v0.end();) {
    if (it1 == v1.end() || *it0 < *it1) {
      res.emplace_back(*it0);
      it0++;
    } else if (*it0 == *it1) {
      it0++;
      it1++;
    } else {
      it1++;
    }
  }
  return res;
}

std::vector<int> seq_union_upper(const std::vector<int>& v0,
                                 const std::vector<int>& v1, int bound) {
  g_set_op_counter++;
  std::vector<int> res;
  for (auto it0 = std::upper_bound(v0.begin(), v0.end(), bound),
            it1 = std::upper_bound(v1.begin(), v1.end(), bound);
       it0 != v0.end() || it1 != v1.end();) {
    if (it1 == v1.end())
      res.emplace_back(*it0++);
    else if (it0 == v0.end())
      res.emplace_back(*it1++);
    else if (*it0 == *it1) {
      res.emplace_back(*it0);
      it0++;
      it1++;
    } else if (*it0 > *it1) {
      res.emplace_back(*it1);
      it1++;
    } else {
      res.emplace_back(*it0);
      it0++;
    }
  }
  return res;
}

void SetOpCounterReset() { g_set_op_counter = 0; }

void SetOpCounterAdd(int num) { g_set_op_counter += num; }

long long GetSetOpCounter() { return g_set_op_counter; }