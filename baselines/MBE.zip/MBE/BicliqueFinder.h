#ifndef MBEA_BICLIQUE_FINDER_H
#define MBEA_BICLIQUE_FINDER_H

#include <cstring>
#include <map>
#include <set>

#include "BiGraph.h"

struct CExtNode {
  int r_id;
  int nc;
  std::vector<int> r_cands;
  CExtNode(int r_id, int nc) : r_id(r_id), nc(nc) {
    r_cands.emplace_back(r_id);
  }
  CExtNode(int r_id, int nc, std::vector<int> r_cands)
      : r_id(r_id), nc(nc), r_cands(r_cands) {}
  CExtNode() : r_id(-1), nc(0), r_cands(0) {}
};

struct PNode {
  int start;
  int size;
  int nc;
  PNode(int start, int size, int nc) : start(start), size(size), nc(nc) {}
};

class BicliqueFinder {
 public:
  BicliqueFinder() = delete;
  BicliqueFinder(BiGraph* graph_in, const char* name);
  virtual void Execute(int min_l_size = 1, int min_r_size = 1) = 0;
  void PrintResult(char* fn = nullptr);
  friend class MEBFinder;

 protected:
  BiGraph* graph_;
  Biclique maximum_biclique_;
  char* finder_name_;
  long long int processing_nodes_, maximal_nodes_;
  int min_l_size_, min_r_size_;
  double exe_time_, start_time_;
  bool is_transposed_;

  inline void Partition(const std::vector<int>& L_prime,
                        const std::vector<CExtNode>& C,
                        std::vector<int>& reordered_map, std::vector<PNode>& P);
  inline void Partition(const std::vector<int>& L_prime,
                        const std::vector<std::pair<int, int>>& C,
                        std::vector<int>& reordered_map, std::vector<PNode>& P);
  inline void Partition(const std::vector<int>& L_prime,
                        const std::vector<int>& C,
                        std::vector<int>& reordered_map,
                        std::vector<std::pair<int, int>>& P);
  void setup(int min_l_size, int min_r_size);
  void finish();

  /**
   * @brief
   *
   * @param X stands for R
   * @param GamaX stands for L
   * @param tailX stands for C
   */
  void MineLMBC(std::vector<int> X, std::vector<int> GamaX,
                std::vector<int> tailX);
};

class MbeaFinder : public BicliqueFinder {
 public:
  MbeaFinder() = delete;
  MbeaFinder(BiGraph* graph_in, const char* name = "MbeaFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(std::vector<int> L, std::vector<int> R, std::vector<int> P,
                     std::vector<int> Q);
};

class ImbeaFinder : public BicliqueFinder {
 public:
  ImbeaFinder() = delete;
  ImbeaFinder(BiGraph* graph_in, const char* name = "ImbeaFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(std::vector<int> L, std::vector<int> R, std::vector<int> P,
                     std::vector<int> Q);
};

class MineLMBCFinder : public BicliqueFinder {
 public:
  MineLMBCFinder() = delete;
  MineLMBCFinder(BiGraph* graph_in, const char* name = "MineLMBCFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);
};

class FmbeFinder : public BicliqueFinder {
 public:
  FmbeFinder() = delete;
  FmbeFinder(BiGraph* graph_in, const char* name = "FmbeFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);
};

class MmbeaIntraFinder : public BicliqueFinder {
 public:
  MmbeaIntraFinder() = delete;
  MmbeaIntraFinder(BiGraph* graph_in, const char* name = "MmbeaIntraFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     std::vector<CExtNode>& C, int vc);
};

class MmbeaIntraFinderV2
    : public BicliqueFinder {  // only keep leading cand vertex
 public:
  MmbeaIntraFinderV2() = delete;
  MmbeaIntraFinderV2(BiGraph* graph_in,
                     const char* name = "MmbeaIntraFinderV2");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     std::vector<int>& C, int vc);
};

class MmbeaInterFinder : public BicliqueFinder {
 public:
  MmbeaInterFinder() = delete;
  MmbeaInterFinder(BiGraph* graph_in, const char* name = "MmbeaInterFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     const std::vector<std::pair<int, int>>& C, int vp, int vc);
};

class MmbeaInterFinderV2 : public BicliqueFinder {
 public:
  MmbeaInterFinderV2() = delete;
  MmbeaInterFinderV2(BiGraph* graph_in,
                     const char* name = "MmbeaInterFinderV2");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     const std::vector<std::pair<int, int>>& C, int vp, int vc);
};

// partition and merge the vertex set to one vertex

class MmbeaFinder : public BicliqueFinder {
 public:
  MmbeaFinder() = delete;
  MmbeaFinder(BiGraph* graph_in, const char* name = "MmbeaFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     std::vector<std::pair<int, int>>& C, int vp, int vc);
};

struct CNode {
  int r_id, nc, size;
  CNode(int r_id, int nc, int size) : r_id(r_id), nc(nc), size(size) {}
};

class MmbeaFinderV2 : public BicliqueFinder {
 public:
  MmbeaFinderV2() = delete;
  MmbeaFinderV2(BiGraph* graph_in, const char* name = "MmbeaFinderV2");
  void Execute(int min_l_size = 1, int min_r_size = 1);

 private:
  void biclique_find(const std::vector<int>& L, const std::vector<int>& R,
                     std::vector<CNode>& C, int vp, int vc);
  void Partition(const std::vector<int>& L_prime, const std::vector<CNode>& C,
                 std::vector<int>& reordered_map, std::vector<PNode>& P);
};

class MEBFinder {
 public:
  MEBFinder() = delete;
  MEBFinder(BiGraph* graph);
  void Execute(int ctrl = 0);
  void PrintResult(char* fn = nullptr);

 private:
  Biclique maximum_biclique_;
  BiGraph* orig_graph_;
  double exe_time_;
};

#endif
