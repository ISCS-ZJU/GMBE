#ifndef MBEA_BICLIQUE_FINDER_H
#define MBEA_BICLIQUE_FINDER_H

#include "BiGraph.h"
#include <atomic>
#include <cstring>
#include <map>
#include <set>

struct CExtNode {
  int r_id;
  int nc;
  std::vector<int> r_cands;
  CExtNode(int r_id, int nc) : r_id(r_id), nc(nc) {
    r_cands.emplace_back(r_id);
  }
  CExtNode(int r_id, int nc, std::vector<int> r_cands)
      : r_id(r_id), nc(nc), r_cands(r_cands) {}
  CExtNode() : r_id(-1), nc(0), r_cands(0) {}
};

struct PNode {
  int start;
  int size;
  int nc;
  PNode(int start, int size, int nc) : start(start), size(size), nc(nc) {}
};

class BicliqueFinder {
public:
  BicliqueFinder() = delete;
  BicliqueFinder(BiGraph *graph_in, const char *name);
  virtual void Execute(int min_l_size = 1, int min_r_size = 1) = 0;
  void PrintResult(char *fn = nullptr);
  friend class MEBFinder;

protected:
  BiGraph *graph_;
  Biclique maximum_biclique_;
  char *finder_name_;
  std::atomic<long long int> processing_nodes_, maximal_nodes_;
  int min_l_size_, min_r_size_;
  double exe_time_, start_time_;
  bool is_transposed_;
  int max_level_;

  inline void Partition(const std::vector<int> &L_prime,
                        const std::vector<CExtNode> &C,
                        std::vector<int> &reordered_map, std::vector<PNode> &P);
  inline void Partition(const std::vector<int> &L_prime,
                        const std::vector<std::pair<int, int>> &C,
                        std::vector<int> &reordered_map, std::vector<PNode> &P);
  inline void Partition(const std::vector<int> &L_prime,
                        const std::vector<int> &C,
                        std::vector<int> &reordered_map,
                        std::vector<std::pair<int, int>> &P);
  void setup(int min_l_size, int min_r_size);
  void finish();

  /**
   * @brief
   *
   * @param X stands for R
   * @param GamaX stands for L
   * @param tailX stands for C
   */
  void MineLMBC(std::vector<int> X, std::vector<int> GamaX,
                std::vector<int> tailX);
};

class MbeaAdvFinder : public BicliqueFinder {
public:
  MbeaAdvFinder() = delete;
  MbeaAdvFinder(BiGraph *graph_in, const char *name = "MbeaAdvFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

private:
  void biclique_find(std::vector<int> L, std::vector<int> R, std::vector<int> P,
                     std::vector<int> Q);
};

class ImbeaFinder : public BicliqueFinder {
public:
  ImbeaFinder() = delete;
  ImbeaFinder(BiGraph *graph_in, const char *name = "ImbeaFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

private:
  void biclique_find(std::vector<int> L, std::vector<int> R, std::vector<int> P,
                     std::vector<int> Q);
};

class ImbeaAdvFinder : public BicliqueFinder {
public:
  ImbeaAdvFinder() = delete;
  ImbeaAdvFinder(BiGraph *graph_in, const char *name = "ImbeaAdvFinder");
  void Execute(int min_l_size = 1, int min_r_size = 1);

private:
  void biclique_find(std::vector<int> L, std::vector<int> R, std::vector<int> P,
                     std::vector<int> Q, int level = 0);
};
#endif
