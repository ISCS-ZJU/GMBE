#include "BicliqueFinder.h"

#include <unordered_map>


BicliqueFinder::BicliqueFinder(BiGraph* graph_in, const char* name) {
  finder_name_ = new char[strlen(name) + 1];
  start_time_ = 0;
  strcpy(finder_name_, name);
  graph_ = graph_in;
  processing_nodes_ = 0;
  maximal_nodes_ = 0;
  min_l_size_ = 1;
  min_r_size_ = 1;
  exe_time_ = 0;
  SetOpCounterReset();
}

void BicliqueFinder::PrintResult(char* fn) {
  FILE* fp = (fn == nullptr || strlen(fn) == 0) ? stdout : fopen(fn, "a+");
  if (fn != nullptr) fseek(fp, 0, SEEK_END);
  fprintf(fp, "Finder name: %s\n", finder_name_);
  fprintf(fp, "Total processing time: %lf seconds\n", exe_time_);
  fprintf(fp, "maximal nodes/processing nodes : %lld/%lld\n", maximal_nodes_,
          processing_nodes_);
  // maximum_biclique_.Print(fp);
  // long long int set_ops = GetSetOpCounter();
  // fprintf(fp, "Total set operations : %lld\n", set_ops);
  fprintf(fp, "\n");
  if (fn != NULL) fclose(fp);
}

MbeaFinder::MbeaFinder(BiGraph* graph_in, const char* name)
    : BicliqueFinder(graph_in, name) {}

void MbeaFinder::Execute(int min_l_size, int min_r_size) {
  setup(min_l_size, min_r_size);

  std::vector<int> L, R, P, Q;
  for (int i = 0; i < graph_->GetLSize(); i++)
    if (graph_->NeighborsL(i).size() >= min_r_size) L.emplace_back(i);
  for (int i = graph_->GetRSize() - 1; i >= 0; i--)
    if (graph_->NeighborsR(i).size() >= min_l_size) P.emplace_back(i);
  biclique_find(L, R, P, Q);
  finish();
}

void MbeaFinder::biclique_find(std::vector<int> L, std::vector<int> R,
                               std::vector<int> P, std::vector<int> Q) {
  while (!P.empty()) {
    std::vector<int> L_prime, R_prime, P_prime, Q_prime;
    bool is_maximal = true;

    int x = P.back();
    P.pop_back();
    L_prime = std::move(seq_intersect(L, graph_->NeighborsR(x)));
    R_prime = R;
    R_prime.emplace_back(x);

    if (L_prime.size() < min_l_size_) {
      Q.emplace_back(x);
      continue;
    }
    processing_nodes_++;

    for (int q : Q) {
      int Nc = seq_intersect_cnt(L_prime, graph_->NeighborsR(q));
      if (Nc == L_prime.size()) {
        is_maximal = false;
        break;
      } else if (Nc >= min_l_size_)
        Q_prime.emplace_back(q);
    }
    if (is_maximal) {
      for (int p : P) {
        int Nc = seq_intersect_cnt(L_prime, graph_->NeighborsR(p));
        if (Nc == L_prime.size())
          R_prime.emplace_back(p);
        else if (Nc >= min_l_size_)
          P_prime.emplace_back(p);
      }

      if (!P_prime.empty() && (R_prime.size() + P_prime.size() >= min_r_size_))
        biclique_find(L_prime, R_prime, P_prime, Q_prime);
      if (R_prime.size() >= min_r_size_) {
        maximal_nodes_++;
        maximum_biclique_.CompareAndSet(L_prime, R_prime, graph_);
      }
    }
    Q.emplace_back(x);
  }
}

ImbeaFinder::ImbeaFinder(BiGraph* graph_in, const char* name)
    : BicliqueFinder(graph_in, name) {}

void ImbeaFinder::Execute(int min_l_size, int min_r_size) {
  setup(min_l_size, min_r_size);

  std::vector<int> L, R, P, Q;
  for (int i = 0; i < graph_->GetLSize(); i++)
    if (graph_->NeighborsL(i).size() >= min_r_size) L.emplace_back(i);
  for (int i = graph_->GetRSize() - 1; i >= 0; i--)
    if (graph_->NeighborsR(i).size() >= min_l_size) P.emplace_back(i);
  std::sort(P.begin(), P.end(), [=](int p0, int p1) -> bool {
    return graph_->NeighborsR(p0).size() > graph_->NeighborsR(p1).size();
  });

  biclique_find(L, R, P, Q);
  finish();
}

void ImbeaFinder::biclique_find(std::vector<int> L, std::vector<int> R,
                                std::vector<int> P, std::vector<int> Q) {
  while (!P.empty()) {
    std::vector<int> L_prime, R_prime, P_prime, Q_prime, L_comple, C;
    bool is_maximal = true;

    int x = P.back();
    P.pop_back();
    L_prime = std::move(seq_intersect(L, graph_->NeighborsR(x)));
    L_comple = std::move(seq_except(L, L_prime));
    R_prime = R;
    R_prime.emplace_back(x);
    C.emplace_back(x);

    if (L_prime.size() < min_l_size_) {
      Q.emplace_back(x);
      continue;
    }

    processing_nodes_++;

    for (int q : Q) {
      int Nc = seq_intersect_cnt(L_prime, graph_->NeighborsR(q));
      if (Nc == L_prime.size()) {
        is_maximal = false;
        break;
      } else if (Nc >= min_l_size_)
        Q_prime.emplace_back(q);
    }

    if (is_maximal) {
      std::vector<std::pair<int, int>> p_prime_with_nc;
      for (int p : P) {
        int Nc = seq_intersect_cnt(L_prime, graph_->NeighborsR(p));
        if (Nc == L_prime.size()) {
          R_prime.emplace_back(p);
          int Nc_comple = seq_intersect_cnt(L_comple, graph_->NeighborsR(p));
          if (Nc_comple == 0) C.emplace_back(p);
        } else if (Nc >= min_l_size_) {
          p_prime_with_nc.emplace_back(std::make_pair(p, Nc));
        }
      }
      if (!p_prime_with_nc.empty() &&
          (R_prime.size() + p_prime_with_nc.size() >= min_r_size_)) {
        std::sort(p_prime_with_nc.begin(), p_prime_with_nc.end(),
                  [&](std::pair<int, int> x0, std::pair<int, int> x1) -> bool {
                    return x0.second > x1.second;
                  });
        P_prime.resize(p_prime_with_nc.size());
        for (int i = 0; i < p_prime_with_nc.size(); i++) {
          P_prime[i] = p_prime_with_nc[i].first;
        }

        biclique_find(L_prime, R_prime, P_prime, Q_prime);
      }

      if (R_prime.size() >= min_r_size_) {
        maximal_nodes_++;
        maximum_biclique_.CompareAndSet(L_prime, R_prime, graph_);
      }
      P = std::move(seq_except(P, C));
      Q.insert(Q.end(), C.begin(), C.end());
    }
  }
}

MineLMBCFinder::MineLMBCFinder(BiGraph* graph_in, const char* name)
    : BicliqueFinder(graph_in, name) {}

void MineLMBCFinder::Execute(int min_l_size, int min_r_size) {
  setup(min_l_size, min_r_size);

  std::vector<int> X, GamaX, tailX;
  for (int i = 0; i < graph_->GetLSize(); i++)
    if (graph_->NeighborsL(i).size() >= min_r_size) GamaX.emplace_back(i);
  for (int i = 0; i < graph_->GetRSize(); i++)
    if (graph_->NeighborsR(i).size() >= min_l_size) tailX.emplace_back(i);

  MineLMBC(X, GamaX, tailX);
  finish();
}

void BicliqueFinder::MineLMBC(std::vector<int> X, std::vector<int> GamaX,
                              std::vector<int> tailX) {
  std::vector<std::pair<int, int>> tailx_with_nc;
  for (int v : tailX) {
    int Nc = seq_intersect_cnt(GamaX, graph_->NeighborsR(v));
    if (Nc >= min_l_size_) tailx_with_nc.emplace_back(std::make_pair(v, Nc));
  }
  if (X.size() + tailx_with_nc.size() < min_r_size_) return;
  std::sort(tailx_with_nc.begin(), tailx_with_nc.end(),
            [&](std::pair<int, int> x0, std::pair<int, int> x1) -> bool {
              return x0.second > x1.second ||
                     (x0.second == x1.second && x0.first > x1.first);
            });
  tailX.clear();
  tailX.resize(tailx_with_nc.size());
  for (int i = 0; i < tailx_with_nc.size(); i++)
    tailX[i] = tailx_with_nc[i].first;
  while (!tailX.empty()) {
    int v = tailX.back();
    std::vector<int> ordered_tailX = tailX;
    std::sort(ordered_tailX.begin(), ordered_tailX.end());
    if (X.size() + tailX.size() >= min_r_size_) {
      auto Nc = seq_intersect(GamaX, graph_->NeighborsR(v));
      std::vector<int> Y = graph_->NeighborsL(Nc);
      processing_nodes_++;
      auto Y_minus_X = seq_except(Y, X);
      if (seq_intersect_cnt(Y_minus_X, ordered_tailX) == Y_minus_X.size()) {
        if (Y.size() >= min_r_size_) {
          maximal_nodes_++;
          maximum_biclique_.CompareAndSet(Nc, Y, graph_);
        }
        MineLMBC(Y, Nc, seq_except(ordered_tailX, Y));
      }
    }
    tailX.pop_back();
  }
}

void BicliqueFinder::setup(int min_l_size, int min_r_size) {
  start_time_ = get_cur_time();
  processing_nodes_ = 0;
  maximal_nodes_ = 0;
  min_l_size_ = min_l_size;
  min_r_size_ = min_r_size;
  maximum_biclique_.Reset();
}

void BicliqueFinder::finish() { exe_time_ = get_cur_time() - start_time_; }
