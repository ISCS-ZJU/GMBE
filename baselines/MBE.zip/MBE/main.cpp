﻿#include <unistd.h>

#include <cstdlib>
#include <iostream>

#include "BicliqueFinder.h"
#include "PMBE.h"

void PrintMemory(char *fn = nullptr) {
  FILE *fp = (fn == nullptr || strlen(fn) == 0) ? stdout : fopen(fn, "a+");
  int pid = getpid();
  unsigned int vmhwm = get_proc_vmhwm(pid);
  if (fn != nullptr)
    fseek(fp, 0, SEEK_END);
  fprintf(fp, "Memory Usage : %lfMB\n", vmhwm / 1000.0);
  if (fn != NULL)
    fclose(fp);
}

void ExpFinderTest(char *graph_name, int finder_sel, char *fn) {
  BiGraph *G = new BiGraph(graph_name);
  G->PrintProfile();
  BicliqueFinder *finder;
  switch (finder_sel) {
  case 0:
    finder = new MbeaAdvFinder(G);
    break;
  case 1:
    finder = new ImbeaAdvFinder(G);
    break;
  case 2:
    finder = new PmbeAdvFinder(G);
    break;
  }
  finder->Execute();
  if (fn != nullptr) {
    FILE *fp = fopen(fn, "a+");
    fprintf(fp, "Graph : %s\t Finder:%d\n", graph_name, finder_sel);
    fclose(fp);
  }
  PrintMemory(fn);
  finder->PrintResult(fn);
  delete finder;
  delete G;
}

int main(int argc, char *argv[]) {
  int opt;
  int thread_num = 1;
  opterr = 0;
  char graph_name[80];
  char *output_fn = nullptr;
  int sel;
  while ((opt = getopt(argc, argv, "i:s:t:l")) != -1) {
    switch (opt) {
    case 'i':
      memcpy(graph_name, optarg, strlen(optarg) + 1);
      break;
    case 's':
      sel = atoi(optarg);
      break;
    }
  }
  ExpFinderTest(graph_name, sel, output_fn);
}
